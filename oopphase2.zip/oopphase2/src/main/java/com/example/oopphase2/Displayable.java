package com.example.oopphase2;

public interface Displayable {
    void display();
}
